package com.ruoyi.common.core.domain.model;

import io.swagger.annotations.ApiModel;

/**
 * 用户注册对象
 *
 * @author Lion Li
 */
@ApiModel("用户注册对象")
public class RegisterBody extends LoginBody {

}
