package com.ruoyi.common.core.validate;

/**
 * 校验分组 edit
 *
 * @author Lion Li
 */
public interface EditGroup {
}
