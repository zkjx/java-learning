package com.ruoyi.common.core.validate;

/**
 * 校验分组 query
 *
 * @author Lion Li
 */
public interface QueryGroup {
}
